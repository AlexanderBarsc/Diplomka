#define OK 200
#define BAD_REQUEST 400